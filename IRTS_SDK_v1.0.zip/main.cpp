/*
 *	Name	:	SDK for Ionosphere Real Time Service(IRTS) 
 *	Version	:	1.0
 *	Update	:	2017-06-10
 *	Website	: 	ionosphere.cn
 *  Author	: 	Cheng Wang
 *  Email	:	ac@ionosphere.cn
 *	Phone	:	+86 13886095630
*/
#include "client.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#ifdef _WIN32
#include <winsock2.h>
#endif

using namespace std;

class MyClient: public client 
{
public:
	MyClient(char *host, int port, char *username, char *password)
	:client(host, port, username, password) {}
};

int main(int argc, char *argv[]) 
{
	char host[20]="irts.iono.cn";
	int port=10086;
	char username[10]="test";
	char password[10]="irts2017";

	MyClient client = MyClient(host,port,username,password);
	if(client.connect())
	{
		double lon=120.0;
		double obs_hour0=13.5; //UTC
		for (double lat = 35; lat < 45; lat+=0.5) 
		{
			double obs_hour1=client.get_utc();
			double vtec=client.get_vtec(lat,lon,obs_hour1);
			cout<<"lat:"<<lat<<",lon:"<<lon<<",utc:"<<obs_hour1<<", VTEC="<<vtec<<" TECU"<<endl;
		}
		client.disconnect();
	}
	cout<<"Hello, IRTS!"<<endl;
	return 1;
}

