/*
 *	Name	:	SDK for Ionosphere Real Time Service(IRTS) 
 *	Version	:	1.0
 *	Update	:	2017-06-10
 *	Website	: 	ionosphere.cn
 *  Author	: 	Cheng Wang
 *  Email	:	ac@ionosphere.cn
 *	Phone	:	+86 13886095630
*/
#ifndef client_H_
#define client_H_

class client {
public:
	client(char *host, int port, char *username, char *password);
	virtual ~client();
	bool connect();
	void disconnect();	
	double get_vtec(double lat, double lon, double obs_time);
	double get_utc();
private:
	char* m_host;
	int m_port;
	char* m_username;
	char* m_password;
	int m_socket;
	int m_buf_length;

	int send(char* cmd);
	int receive();
	char* m_data;
	int m_length;
};

#endif /* client_H_ */
